import 'package:flutter/material.dart';
import 'package:web_config/models/appbarResponse_model.dart';
import 'package:web_config/presentation/widgets/error_data_widget.dart';
import 'package:web_config/presentation/widgets/no_data_widget.dart';
import 'package:web_config/services/appbar_service.dart';

class AppbarScreen extends StatelessWidget {
  const AppbarScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          centerTitle: true,
          title: const Text(
            'Configuración del appbar',
          ),
        ),
        body: _AppbarView());
  }
}

class _AppbarView extends StatelessWidget {
  const _AppbarView({super.key});

  @override
  Widget build(BuildContext context) {
    AppbarService appbarService = AppbarService();
    Future<AppbarResponse> appbar = appbarService.getAppbar();
    return Scaffold(
        body: Container(
      child: FutureBuilder<AppbarResponse>(
        future: appbar,
        builder:
            (BuildContext context, AsyncSnapshot<AppbarResponse> snapshot) {
          if (snapshot.hasData) {
            return ModificarAppbar(appbar: snapshot.data!);
          } else if (snapshot.hasError) {
            return const Center(child: ErrorDataWidget());
          } else {
            return const Center(child: NoDataWidget());
          }
        },
      ),
    ));
  }
}

class ModificarAppbar extends StatefulWidget {
  final AppbarResponse appbar;
  const ModificarAppbar({super.key, required this.appbar});

  @override
  State<ModificarAppbar> createState() => _ModificarAppbarState();
}

class _ModificarAppbarState extends State<ModificarAppbar> {
  String tituloNuevo = '';
  @override
  Widget build(BuildContext context) {
    AppbarService appbarService = AppbarService();

    return Column(
      children: [
        Text('El título actual del apbar es ${widget.appbar.titulo}'),
        const SizedBox(
          height: 20,
        ),
        Form(
            child: Column(
          children: [
            TextFormField(
                decoration:
                    const InputDecoration(label: Text('Nuevo titulo:')),
                onChanged: (value) {
                  tituloNuevo = value;
                  setState(() {});
                }),
            FilledButton.tonalIcon(
                onPressed: () {
                  widget.appbar.titulo = tituloNuevo;
                  appbarService.putAppbar(widget.appbar);
                  setState(() {});
                },
                label: const Text('Guardar cambios'))
          ],
        ))
      ],
    );
  }
}
