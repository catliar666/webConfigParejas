import 'package:flutter/material.dart';
import 'package:web_config/models/configResponse_model.dart';
import 'package:web_config/presentation/widgets/error_data_widget.dart';
import 'package:web_config/presentation/widgets/no_data_widget.dart';
import 'package:web_config/services/config_service.dart';

class ConfigScreen extends StatelessWidget {
  const ConfigScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          centerTitle: true,
          title: const Text(
            'Configuración del config',
          ),
        ),
        body: _ConfigView());
  }
}

class _ConfigView extends StatelessWidget {
  const _ConfigView({super.key});

  @override
  Widget build(BuildContext context) {
    ConfigService appbarService = ConfigService();
    Future<ConfigResponse> appbar = appbarService.getConfig();
    return Scaffold(
        body: Container(
      child: FutureBuilder<ConfigResponse>(
        future: appbar,
        builder:
            (BuildContext context, AsyncSnapshot<ConfigResponse> snapshot) {
          if (snapshot.hasData) {
            return ModificarConfig(config: snapshot.data!);
          } else if (snapshot.hasError) {
            return const Center(child: ErrorDataWidget());
          } else {
            return const Center(child: NoDataWidget());
          }
        },
      ),
    ));
  }
}

class ModificarConfig extends StatefulWidget {
  final ConfigResponse config;
  const ModificarConfig({super.key, required this.config});

  @override
  State<ModificarConfig> createState() => _ModificarConfigState();
}

class _ModificarConfigState extends State<ModificarConfig> {
  String autores = '';
  String curso = '';
  String anio = '';
  bool haySplash = false;
  @override
  Widget build(BuildContext context) {
    ConfigService configService = ConfigService();

    return Column(
      children: [
        Text('los autores actuales son  ${widget.config.autores}'),
        const SizedBox(
          height: 20,
        ),
        Text('El curso actual es  ${widget.config.curso}'),
        const SizedBox(
          height: 20,
        ),
        Text('El año actual es  ${widget.config.anio}'),
        const SizedBox(
          height: 20,
        ),
        Text(
            '¿Hay splashScreen?:   ${(widget.config.splashScreen ? 'Si' : 'No')}'),
        const SizedBox(
          height: 20,
        ),
        Form(
            child: Column(
          children: [
            TextFormField(
                decoration:
                    const InputDecoration(label: Text('Nuevos autores:')),
                onChanged: (value) {
                  widget.config.autores = value;
                  setState(() {});
                }),
            TextFormField(
                decoration: const InputDecoration(label: Text('Nuevo curso:')),
                onChanged: (value) {
                  widget.config.curso = value;
                  setState(() {});
                }),
            TextFormField(
                decoration: const InputDecoration(label: Text('Nuevo año:')),
                onChanged: (value) {
                  widget.config.anio = value as int;
                  setState(() {});
                }),
            Row(
              children: [
                Text('¿Quieres mostrar el SplashScreen?'),
                Switch(
                    value: widget.config.splashScreen,
                    onChanged: (bool newValue) {
                      widget.config.splashScreen = newValue;
                      setState(() {});
                    }),
              ],
            ),
            FilledButton.tonalIcon(
                onPressed: () {
                  configService.putConfig(widget.config);
                  setState(() {});
                },
                label: const Text('Guardar cambios'))
          ],
        ))
      ],
    );
  }
}
